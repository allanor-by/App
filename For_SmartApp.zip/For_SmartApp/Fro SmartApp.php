<?php
/*
Plugin Name: For Smart App
Description: Плагин для тестового задания SmartApp
Author: Andrey Alipov
*/

require_once plugin_dir_path(__FILE__) . 'includes/fsa-functions.php';