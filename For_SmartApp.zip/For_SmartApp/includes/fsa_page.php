<div class="wrap">
 <h1>For smartApp</h1>
 <p>link to the form <a href="/wp-content/plugins/For_SmartApp/public/post.php">here</p>
</div>